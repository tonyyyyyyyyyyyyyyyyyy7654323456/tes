import { useEffect } from 'react'
import { CheckCircle2, X } from 'lucide-react'

interface ToastProps {
  message: string
  type?: 'success' | 'error'
  onClose: () => void
}

export function Toast({ message, type = 'success', onClose }: ToastProps) {
  useEffect(() => {
    const t = setTimeout(onClose, 3000)
    return () => clearTimeout(t)
  }, [onClose])

  return (
    <div className="fixed bottom-6 right-6 z-50 bg-navy-raised border border-white/[0.13] rounded-xl px-5 py-3 text-sm text-white flex items-center gap-3 shadow-2xl">
      {type === 'success'
        ? <CheckCircle2 className="w-4 h-4 text-gain flex-shrink-0" />
        : <X className="w-4 h-4 text-loss flex-shrink-0" />
      }
      <span>{message}</span>
      <button onClick={onClose} className="ml-2 text-white/30 hover:text-white/70">
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  )
}
